import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import Button from 'react-bootstrap/Button';
import '../../css/LandingPage/HeadBar.css'

function HeadBar(){
    return (
        <Navbar className="my-navbar">
        <Container>
            <Navbar.Brand href="#home" className="text-white fs-2">UrNextJob</Navbar.Brand>
            <Navbar.Toggle />
            <Navbar.Collapse className="justify-content-end">
            <Button variant="outline-light">Iniciar Sesión</Button>
            </Navbar.Collapse>
        </Container>
        </Navbar>
    )
}

export default HeadBar;